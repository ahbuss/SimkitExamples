package simkit.test;

/*
 * TestPlatformType.java
 *
 * Created on December 6, 2001, 5:20 PM
 */

/**
 *
 * @author  ahbuss
 * 
 */
public class TestPlatformType {

    /** Creates new TestPlatformType */
    public TestPlatformType() {
    }

    /**
    * @param args the command line arguments
    */
    public static void main (String args[]) {
        System.out.println(PlatformType.BAD_GUY);
        System.out.println(PlatformType.LOITERER);
        System.out.println(PlatformType.PASSERBY);
        System.out.println(PlatformType.PATROL_BOAT);
    }

}
