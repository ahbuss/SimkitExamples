package simkit.stat;

/**
 *
 * @author ahbuss
 */
public enum OuterStatType {
    MIN,
    MAX,
    MEAN,
    STD,
    VARIANCE,
    COUNT
}
